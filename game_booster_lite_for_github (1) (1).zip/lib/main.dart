
import 'package:flutter/material.dart';
import 'package:device_apps/device_apps.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(GameBoosterApp());
}

class GameBoosterApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Game Booster Lite',
      theme: ThemeData.dark(),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  Future<void> _boostPhone(BuildContext context) async {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('🔋 Boosting phone performance...')),
    );
    await Future.delayed(Duration(seconds: 2));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('✅ Boost complete!')),
    );
  }

  Future<void> _openGameList(BuildContext context) async {
    List<Application> apps = await DeviceApps.getInstalledApplications(
      onlyAppsWithLaunchIntent: true,
      includeSystemApps: false,
    );

    List<Application> games = apps.where((app) =>
      app.category == ApplicationCategory.game ||
      app.appName.toLowerCase().contains("game")
    ).toList();

    showModalBottomSheet(
      context: context,
      builder: (context) => ListView(
        children: games.map((game) => ListTile(
          leading: game is ApplicationWithIcon ? Image.memory(game.icon, width: 40) : null,
          title: Text(game.appName),
          onTap: () => DeviceApps.openApp(game.packageName),
        )).toList(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Game Booster Lite'),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton.icon(
              icon: Icon(Icons.speed),
              label: Text('One Tap Boost'),
              onPressed: () => _boostPhone(context),
              style: ElevatedButton.styleFrom(padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15)),
            ),
            SizedBox(height: 20),
            ElevatedButton.icon(
              icon: Icon(Icons.games),
              label: Text('Launch Games'),
              onPressed: () => _openGameList(context),
              style: ElevatedButton.styleFrom(padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15)),
            ),
          ],
        ),
      ),
    );
  }
}
